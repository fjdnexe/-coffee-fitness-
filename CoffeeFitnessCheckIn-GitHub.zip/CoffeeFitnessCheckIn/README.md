# 咖啡健身打卡 App

Jetpack Compose 编写的打卡应用，苹果运动风格界面。

## 功能

- 咖啡打卡 / 健身打卡，按「天」计数，可 +1 / -1
- 首页：圆环显示今日进度（咖啡目标 3 杯、健身目标 1 次），点卡片进详情
- 详情：周视图 / 月视图切换，合计、打卡天数、单日最高、柱状图
- 跟随系统深色模式；沉浸式全屏（状态栏与手势条不遮挡内容）
- 数据存本地（SharedPreferences），不需要网络、不需要权限
- minSdk 35（Android 15 及以上），targetSdk 35

## 结构

```
app/src/main/java/com/daily/checkin/
  MainActivity.kt   入口 + 沉浸式
  Store.kt          数据存取 + 周/月日期
  ui/Theme.kt       配色与深色模式
  ui/Ring.kt        运动风格圆环
  ui/Widgets.kt     按钮、分段控件
  ui/Home.kt        首页
  ui/Detail.kt      详情页
  ui/Chart.kt       柱状图
```

## 用 GitHub 打包成 APK（全程手机）

1. 新建 GitHub 仓库（私有也行）：github.com/new，仓库名随意，选 Private/Public，Create。
2. 进入仓库 → Code → **Add file → Upload files**，把本压缩包 `sources.zip` 传上去，Commit。
3. **Add file → Create new file**，文件名一栏输入 `.github/workflows/build.yml`
   （注意带斜杠会自动建目录），内容粘贴仓库同名文件里的 YAML，Commit。
4. 顶部 **Actions** 标签 → 点进 Build APK → 等 2~5 分钟跑完。
5. 页面底部 **Artifacts** → 点 `CoffeeFitness-debug-apk` 下载（需登录 GitHub）。
   下载得到 zip，解压出 `app-debug.apk`，点击安装（允许安装未知来源）。
6. 以后每次改代码重新上传 `sources.zip`，Actions 会自动重新打包，同样方式下载。

## 改需求

把新需求告诉小爱，重新生成 `sources.zip` 后覆盖上传即可，不用动 build.yml。

## 常见调整

- 手机系统低于 Android 15 装不上 → 需要把 `app/build.gradle.kts` 里
  `minSdk = 35` 改小（如 30），重新打包。
- 想发布正式版（不带调试签名） → 改用 `assembleRelease` 并配置签名，需要可告诉小爱。
