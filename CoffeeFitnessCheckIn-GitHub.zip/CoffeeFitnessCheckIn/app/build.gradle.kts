plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.daily.checkin"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.daily.checkin"
        minSdk = 35
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        debug {
            // Debug 包也开启 R8 混淆 + 资源压缩，显著减小 APK 体积
            isMinifyEnabled = true
            isShrinkResources = true
            // 【功耗关键项】debug 包默认 debuggable=true，ART 会跳过 AOT/JIT 优化，
            // 全部字节码走解释执行，滚动 + 实时模糊这种 CPU/GPU 密集场景发热非常明显。
            // 关掉后签名仍是 debug key、可直接安装，但运行性能接近 release。
            isDebuggable = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        compose = true
    }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.10.01"))
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.animation:animation")
    implementation("androidx.compose.animation:animation-core")
    // 真实背景模糊（柔光玻璃）：与本项目 Compose 1.7.5 / Kotlin 2.0.21 对齐
    implementation("dev.chrisbanes.haze:haze:1.0.0")
    // PopupWindow 内的 ComposeView 需要手动设置 ViewTree 的 Lifecycle/ViewModel/SavedState Owner
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    implementation("androidx.lifecycle:lifecycle-viewmodel-ktx:2.8.7")
    implementation("androidx.savedstate:savedstate-ktx:1.2.1")
}
