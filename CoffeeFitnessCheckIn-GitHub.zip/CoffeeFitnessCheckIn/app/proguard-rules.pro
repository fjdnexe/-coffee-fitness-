# Haze 通过 Compose 图层渲染，不依赖反射；保留其公开 API 以防万一
-keep class dev.chrisbanes.haze.** { *; }

# Compose / Kotlin 元数据常规保留（AGP 已内置大部分 consumer 规则）
-dontwarn org.jetbrains.annotations.**
