package com.daily.checkin.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.daily.checkin.Store
import com.daily.checkin.monthDates
import com.daily.checkin.weekDates
import java.time.LocalDate

/** 详情页：周 / 月视图 + 柱状图 + 今日加减 */
@Composable
fun Detail(store: Store, type: String, onBack: () -> Unit) {
    val p = palette()
    var mode by remember { mutableStateOf(0) }
    val today = LocalDate.now()
    val coffee = type == "coffee"
    val title = if (coffee) "咖啡打卡" else "健身打卡"
    val unit = if (coffee) "杯" else "次"
    val goal = if (coffee) 3 else 1
    val cA = if (coffee) CoffeeA else GymA
    val cB = if (coffee) CoffeeB else GymB

    val dates = if (mode == 0) weekDates() else monthDates()
    val data = store.series(type, dates)
    val total = data.sumOf { it.second }
    val activeDays = data.count { it.second > 0 }
    val best = data.maxOfOrNull { it.second } ?: 0
    val todayCount = store.count(type, today)

    Column(
        Modifier
            .fillMaxSize()
            .background(p.bg)
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(horizontal = 20.dp)
    ) {
        Spacer(Modifier.height(12.dp))
        Text(
            "‹ 返回",
            color = cA,
            fontSize = 17.sp,
            modifier = Modifier.clickable(onClick = onBack)
        )
        Spacer(Modifier.height(20.dp))
        Text(title, color = p.text, fontSize = 30.sp, fontWeight = FontWeight.Black)
        Spacer(Modifier.height(18.dp))
        Segmented(listOf("周", "月"), mode) { mode = it }
        Spacer(Modifier.height(26.dp))

        // 合计 + 统计
        Row(verticalAlignment = Alignment.Bottom) {
            Column {
                Text(
                    if (mode == 0) "本周合计" else "本月合计",
                    color = p.dim, fontSize = 14.sp
                )
                Spacer(Modifier.height(2.dp))
                Row(verticalAlignment = Alignment.Bottom) {
                    Text("$total", color = p.text, fontSize = 54.sp, fontWeight = FontWeight.Black)
                    Spacer(Modifier.width(6.dp))
                    Text(unit, color = p.dim, fontSize = 18.sp, modifier = Modifier.padding(bottom = 9.dp))
                }
            }
            Spacer(Modifier.weight(1f))
            Column(
                horizontalAlignment = Alignment.End,
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Stat("打卡天数", "$activeDays 天", p)
                Stat("单日最高", "$best $unit", p)
            }
        }
        Spacer(Modifier.height(24.dp))

        Chart(data, dates, cA, cB, p)
        Spacer(Modifier.weight(1f))

        // 今日加减
        Row(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(20.dp))
                .background(p.card)
                .padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text("今天", color = p.text, fontSize = 16.sp, fontWeight = FontWeight.Medium)
                Text("$todayCount $unit", color = p.dim, fontSize = 13.sp)
            }
            Spacer(Modifier.weight(1f))
            Btn("-1", Brush.horizontalGradient(listOf(p.track, p.track)), p.dim) {
                store.add(type, today, -1)
            }
            Spacer(Modifier.width(10.dp))
            Btn("+1", Brush.horizontalGradient(listOf(cA, cB))) {
                store.add(type, today, 1)
            }
        }
        Spacer(Modifier.height(16.dp))
    }
}

@Composable
private fun Stat(label: String, value: String, p: Palette) {
    Column(horizontalAlignment = Alignment.End) {
        Text(label, color = p.dim, fontSize = 12.sp)
        Text(value, color = p.text, fontSize = 18.sp, fontWeight = FontWeight.Bold)
    }
}
