package com.daily.checkin.ui

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.LocalDate

/** 打卡记录图：Y 轴刻度 + 网格线 + 逐根动画的圆角渐变柱 */
@Composable
fun Chart(
    data: List<Pair<LocalDate, Int>>,
    dates: List<LocalDate>,
    cA: Color,
    cB: Color,
    colors: PageColors
) {
    val maxV = (data.maxOfOrNull { it.second } ?: 0).coerceAtLeast(1)
    val month = dates.size > 10
    val gap = if (month) 2.dp else 10.dp

    Row(Modifier.fillMaxWidth()) {
        // Y 轴刻度 0..max
        Column(
            Modifier
                .width(18.dp)
                .height(170.dp),
            verticalArrangement = Arrangement.SpaceBetween,
            horizontalAlignment = Alignment.End
        ) {
            for (i in maxV downTo 0) {
                Text("$i", color = colors.dim, fontSize = 10.sp)
            }
        }
        Spacer(Modifier.width(6.dp))

        Column(Modifier.weight(1f)) {
            Box(Modifier.fillMaxWidth().height(170.dp)) {
                // 网格线
                Canvas(Modifier.fillMaxWidth().height(170.dp)) {
                    val step = size.height / maxV
                    for (i in 0..maxV) {
                        val y = size.height - step * i
                        drawLine(
                            colors.track,
                            Offset(0f, y),
                            Offset(size.width, y),
                            strokeWidth = 1.5f
                        )
                    }
                }
                // 柱状动画
                Row(
                    Modifier.fillMaxWidth().height(170.dp),
                    horizontalArrangement = Arrangement.spacedBy(gap),
                    verticalAlignment = Alignment.Bottom
                ) {
                    data.forEach { (_, v) ->
                        Bar(v, maxV, cA, cB, colors.track, Modifier.weight(1f))
                    }
                }
            }
            Spacer(Modifier.height(6.dp))
            // X 轴标签
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(gap)
            ) {
                dates.forEach { d ->
                    Text(
                        text = label(d, dates),
                        modifier = Modifier.weight(1f),
                        color = colors.dim,
                        fontSize = if (month) 9.sp else 11.sp,
                        textAlign = TextAlign.Center,
                        maxLines = 1
                    )
                }
            }
        }
    }
}

@Composable
private fun Bar(
    v: Int,
    maxV: Int,
    cA: Color,
    cB: Color,
    track: Color,
    modifier: Modifier
) {
    val target = if (v <= 0) 4f else 16f + 130f * v / maxV
    val h by animateDpAsState(
        targetValue = target.dp,
        animationSpec = tween(500, easing = FastOutSlowInEasing),
        label = "bar"
    )
    val base = Modifier.fillMaxWidth().height(h)
    val decorated = if (v <= 0) {
        base.background(track, RoundedCornerShape(4.dp))
    } else {
        base.background(Brush.verticalGradient(listOf(cA, cB)), RoundedCornerShape(4.dp))
    }
    Column(
        modifier.fillMaxHeight(),
        verticalArrangement = Arrangement.Bottom
    ) {
        Box(decorated)
    }
}

/** 周视图显示星期字，月视图仅关键日显示日期 */
private fun label(d: LocalDate, dates: List<LocalDate>): String {
    if (dates.size <= 7) {
        return "一二三四五六日"[d.dayOfWeek.value - 1].toString()
    }
    val day = d.dayOfMonth
    val last = dates.size
    return when {
        day == 1 -> "1"
        day == last -> "$day"
        else -> ""
    }
}
