package com.daily.checkin.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.LocalDate

/**
 * 柱状图：周视图 7 根、月视图按当月天数，苹果运动风格圆角渐变柱
 */
@Composable
fun Chart(
    data: List<Pair<LocalDate, Int>>,
    dates: List<LocalDate>,
    cA: Color,
    cB: Color,
    p: Palette
) {
    val maxV = (data.maxOfOrNull { it.second } ?: 0).coerceAtLeast(1)
    val month = dates.size > 10
    val gap = if (month) 2.dp else 8.dp

    Column(Modifier.fillMaxWidth()) {
        Row(
            Modifier
                .fillMaxWidth()
                .height(170.dp),
            horizontalArrangement = Arrangement.spacedBy(gap),
            verticalAlignment = Alignment.Bottom
        ) {
            data.forEach { (_, v) ->
                val h = if (v <= 0) 4.dp else (14f + 150f * v / maxV).dp
                Column(
                    Modifier
                        .weight(1f)
                        .fillMaxHeight(),
                    verticalArrangement = Arrangement.Bottom
                ) {
                    // 空值用纯色占位，有值用渐变柱（避免 Color/Brush 混支类型冲突）
                    if (v <= 0) {
                        Box(
                            Modifier
                                .fillMaxWidth()
                                .height(h)
                                .background(p.track, RoundedCornerShape(4.dp))
                        )
                    } else {
                        Box(
                            Modifier
                                .fillMaxWidth()
                                .height(h)
                                .background(
                                    Brush.verticalGradient(listOf(cA, cB)),
                                    RoundedCornerShape(4.dp)
                                )
                        )
                    }
                }
            }
        }
        Spacer(Modifier.height(8.dp))
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(gap)
        ) {
            dates.forEach { d ->
                Text(
                    text = label(d, dates),
                    modifier = Modifier.weight(1f),
                    color = p.dim,
                    fontSize = if (month) 9.sp else 12.sp,
                    textAlign = TextAlign.Center,
                    maxLines = 1
                )
            }
        }
    }
}

/** 周视图显示星期字，月视图仅关键日显示日期 */
private fun label(d: LocalDate, dates: List<LocalDate>): String {
    if (dates.size <= 7) {
        return "一二三四五六日"[d.dayOfWeek.value - 1].toString()
    }
    val day = d.dayOfMonth
    val last = dates.size
    return when {
        day == 1 -> "1"
        day == last -> "$day"
        else -> ""
    }
}
