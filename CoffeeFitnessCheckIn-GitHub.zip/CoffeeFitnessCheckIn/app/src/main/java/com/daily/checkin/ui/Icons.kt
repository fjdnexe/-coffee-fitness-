package com.daily.checkin.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/** 咖啡杯图标（矢量绘制，可任意换色缩放） */
@Composable
fun CoffeeIcon(color: Color, size: Dp = 28.dp) {
    Canvas(Modifier.size(size)) {
        val w = this.size.width
        val h = this.size.height
        val cupW = w * 0.58f
        val cupH = h * 0.40f
        val cupL = (w - cupW) / 2f - w * 0.05f
        val cupT = h * 0.44f

        // 杯身
        drawRoundRect(
            color,
            topLeft = Offset(cupL, cupT),
            size = Size(cupW, cupH),
            cornerRadius = CornerRadius(cupW * 0.30f, cupW * 0.30f)
        )
        // 把手
        drawArc(
            color, -75f, 150f, false,
            topLeft = Offset(cupL + cupW * 0.78f, cupT + cupH * 0.10f),
            size = Size(cupW * 0.45f, cupH * 0.70f),
            style = Stroke(width = w * 0.075f, cap = StrokeCap.Round)
        )
        // 底碟
        drawRoundRect(
            color,
            topLeft = Offset(cupL - w * 0.06f, cupT + cupH + h * 0.06f),
            size = Size(cupW * 1.22f, h * 0.07f),
            cornerRadius = CornerRadius(h * 0.04f, h * 0.04f)
        )
        // 热气
        val steamW = w * 0.07f
        drawLine(
            color,
            Offset(cupL + cupW * 0.22f, h * 0.16f),
            Offset(cupL + cupW * 0.22f, h * 0.34f),
            strokeWidth = steamW, cap = StrokeCap.Round
        )
        drawLine(
            color,
            Offset(cupL + cupW * 0.55f, h * 0.10f),
            Offset(cupL + cupW * 0.55f, h * 0.30f),
            strokeWidth = steamW, cap = StrokeCap.Round
        )
    }
}

/** 哑铃图标 */
@Composable
fun GymIcon(color: Color, size: Dp = 28.dp) {
    Canvas(Modifier.size(size)) {
        val w = this.size.width
        val h = this.size.height
        val cy = h / 2f
        val barH = h * 0.15f

        // 中间横杆
        drawRoundRect(
            color,
            topLeft = Offset(w * 0.24f, cy - barH / 2f),
            size = Size(w * 0.52f, barH),
            cornerRadius = CornerRadius(barH / 2f, barH / 2f)
        )
        // 内侧配重块
        fun plate(x: Float, ww: Float, hh: Float) = drawRoundRect(
            color,
            topLeft = Offset(x, cy - hh / 2f),
            size = Size(ww, hh),
            cornerRadius = CornerRadius(h * 0.07f, h * 0.07f)
        )
        plate(w * 0.15f, w * 0.11f, h * 0.54f)
        plate(w * 0.74f, w * 0.11f, h * 0.54f)
        // 外侧配重块
        plate(w * 0.04f, w * 0.09f, h * 0.36f)
        plate(w * 0.87f, w * 0.09f, h * 0.36f)
    }
}
