package com.daily.checkin.ui

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateIntAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.daily.checkin.Store
import com.daily.checkin.monthDates

/** 三格统计卡：本周 / 本月 / 累计，数字带滚动动画 */
@Composable
fun StatsCard(store: Store, type: String, colors: PageColors, version: Int) {
    val stats = remember(version) {
        Triple(store.weekDayCount(type), store.monthDayCount(type), store.total(type))
    }
    val monthDays = remember { monthDates().size }
    val spec = tween<Int>(500, easing = FastOutSlowInEasing)
    val week by animateIntAsState(stats.first, spec, label = "week")
    val month by animateIntAsState(stats.second, spec, label = "month")
    val total by animateIntAsState(stats.third, spec, label = "total")

    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(24.dp))
            .background(glassFill(colors))
            .border(1.dp, glassRim(colors), RoundedCornerShape(24.dp))
            .padding(vertical = 18.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        StatCell("本周打卡", week, "/7天", colors, Modifier.weight(1f))
        VDivider(colors)
        StatCell("本月打卡", month, "/$monthDays 天", colors, Modifier.weight(1f))
        VDivider(colors)
        StatCell("累计打卡", total, "次", colors, Modifier.weight(1f))
    }
}

@Composable
private fun StatCell(
    label: String,
    value: Int,
    unit: String,
    colors: PageColors,
    modifier: Modifier
) {
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, color = colors.dim, fontSize = 12.sp)
        Spacer(Modifier.height(6.dp))
        Text("$value", color = colors.text, fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(2.dp))
        Text(unit, color = colors.dim, fontSize = 11.sp)
    }
}

@Composable
private fun VDivider(colors: PageColors) {
    Box(Modifier.width(1.dp).height(44.dp).background(colors.divider))
}

/** 连续打卡成就卡 */
@Composable
fun StreakCard(store: Store, type: String, colors: PageColors, version: Int) {
    val target = remember(version) { store.streak(type) }
    val streak by animateIntAsState(
        target,
        tween(500, easing = FastOutSlowInEasing),
        label = "streak"
    )
    val isCoffee = type == "coffee"
    val achievement = if (isCoffee) "咖啡达人" else "运动新手"
    val sub = if (streak < 7) {
        "再坚持 ${7 - streak} 天，解锁「$achievement」成就"
    } else {
        "已解锁「$achievement」成就，继续保持"
    }

    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(24.dp))
            .background(glassFill(colors))
            .border(1.dp, glassRim(colors), RoundedCornerShape(24.dp))
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier
                .size(44.dp)
                .clip(CircleShape)
                .background(colors.chip),
            contentAlignment = Alignment.Center
        ) {
            if (isCoffee) CoffeeIcon(colors.accent, 24.dp) else GymIcon(colors.accent, 24.dp)
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                "本周连续打卡 $streak 天",
                color = colors.text,
                fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(Modifier.height(3.dp))
            Text(sub, color = colors.dim, fontSize = 12.sp)
        }
        Text("›", color = colors.dim, fontSize = 20.sp)
    }
}
