package com.daily.checkin.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import dev.chrisbanes.haze.HazeState
import dev.chrisbanes.haze.HazeTint
import dev.chrisbanes.haze.hazeChild

/** 分段控件（周视图 / 月视图） */
@Composable
fun Segmented(
    items: List<String>,
    index: Int,
    onChange: (Int) -> Unit,
    colors: PageColors,
    accent: Color
) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(colors.seg)
            .padding(3.dp)
    ) {
        items.forEachIndexed { i, t ->
            val selected = i == index
            Box(
                Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(8.dp))
                    .background(if (selected) accent else Color.Transparent)
                    .clickable { onChange(i) }
                    .padding(vertical = 7.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    t,
                    color = if (selected) Color.White else colors.dim,
                    fontSize = 13.sp,
                    fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal
                )
            }
        }
    }
}

/**
 * 底部悬浮玻璃导航栏。
 *
 * 现在它被放进一个独立的 [android.widget.PopupWindow] 里（见 MainActivity.showGlassNav），
 * 背景模糊由 **系统的跨窗口模糊**（Window#setBackgroundBlurRadius）完成，由 SurfaceFlinger
 * 合成，App 端不跑 RenderEffect —— 这是功耗最低、也最接近系统级毛玻璃的做法。
 * 因此这里不再需要 Haze，也不再自己处理导航栏 insets（位置由弹窗决定），
 * 只负责画玻璃表面：半透明渐变 + 顶部天光 + 边缘高光描边。
 */
@Composable
fun FloatingBottomBar(
    current: Tab,
    modifier: Modifier = Modifier,
    systemBlur: Boolean = true,
    onChange: (Tab) -> Unit
) {
    val dark = isSystemInDarkTheme()
    val shape = RoundedCornerShape(25.5.dp)
    val inactive = if (dark) Color(0xFF8E8E93) else Color(0xFF9AA0AC)
    val coffeeAccent = pageColors(Tab.COFFEE).accent
    val gymAccent = pageColors(Tab.GYM).accent

    // 柔光玻璃配色（HyperOS 4 风格）：低透明度多层渐变，模拟玻璃透光
    // 深色模式：进一步降低不透明度（更透），并减淡高光描边
    // systemBlur = 系统跨窗口模糊不可用时（部分 ROM 禁用了 AOSP 的 cross-window blur），
    // 自动把底色压得更实，避免看起来只是一层薄薄的半透明白。
    val glassTop: Color
    val glassMid: Color
    val glassBottom: Color
    if (dark) {
        if (systemBlur) {
            glassTop = Color(0xB32C2C2E); glassMid = Color(0x99252426); glassBottom = Color(0x80201E1F)
        } else {
            glassTop = Color(0xE62C2C2E); glassMid = Color(0xD9252426); glassBottom = Color(0xCC201E1F)
        }
    } else {
        if (systemBlur) {
            glassTop = Color(0xCCFFFFFF); glassMid = Color(0xB3FCF7F0); glassBottom = Color(0x99F7F1E8)
        } else {
            glassTop = Color(0xF0FFFFFF); glassMid = Color(0xE6FCF7F0); glassBottom = Color(0xD9F7F1E8)
        }
    }
    val sheen = if (dark) Color(0x2EFFFFFF) else Color(0xE6FFFFFF)
    val hairline = if (dark) Color(0x33FFFFFF) else Color(0x8CFFFFFF)
    val hairWidth = if (dark) 0.5.dp else 1.dp

    Box(
        modifier.fillMaxWidth(),
        contentAlignment = Alignment.Center
    ) {
        Box(
            Modifier
                .fillMaxWidth()
                .height(51.dp)
                .clip(shape)
                .background(Brush.verticalGradient(listOf(glassTop, glassMid, glassBottom)))
        ) {
            // 柔光：顶部天光反射
            Box(
                Modifier
                    .matchParentSize()
                    .background(
                        Brush.verticalGradient(0f to sheen, 0.62f to Color.Transparent)
                    )
            )
            // 边缘高光描边（模拟玻璃反光）
            Box(
                Modifier
                    .matchParentSize()
                    .border(hairWidth, hairline, shape)
            )
            Row(
                Modifier.fillMaxWidth().fillMaxHeight(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                BarItem(
                    Tab.COFFEE, "咖啡", current, coffeeAccent, inactive,
                    Modifier.weight(1f)
                ) { onChange(Tab.COFFEE) }
                BarItem(
                    Tab.GYM, "健身", current, gymAccent, inactive,
                    Modifier.weight(1f)
                ) { onChange(Tab.GYM) }
            }
        }
    }
}

@Composable
private fun BarItem(
    tab: Tab,
    label: String,
    current: Tab,
    accent: Color,
    inactive: Color,
    modifier: Modifier,
    onClick: () -> Unit
) {
    val active = current == tab
    val c = if (active) accent else inactive
    Column(
        modifier
            .fillMaxHeight()
            .clip(RoundedCornerShape(25.5.dp))
            .clickable(onClick = onClick)
            .padding(vertical = 5.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(1.dp, Alignment.CenterVertically)
    ) {
        if (tab == Tab.COFFEE) CoffeeIcon(c, 20.dp) else GymIcon(c, 20.dp)
        Text(
            label,
            color = c,
            fontSize = 11.sp,
            lineHeight = 13.sp,
            fontWeight = if (active) FontWeight.SemiBold else FontWeight.Medium,
            maxLines = 1,
            softWrap = false
        )
    }
}
