package com.daily.checkin.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import dev.chrisbanes.haze.HazeState
import dev.chrisbanes.haze.HazeTint
import dev.chrisbanes.haze.hazeChild

/** 分段控件（周视图 / 月视图） */
@Composable
fun Segmented(
    items: List<String>,
    index: Int,
    onChange: (Int) -> Unit,
    colors: PageColors,
    accent: Color
) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(colors.seg)
            .padding(3.dp)
    ) {
        items.forEachIndexed { i, t ->
            val selected = i == index
            Box(
                Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(8.dp))
                    .background(if (selected) accent else Color.Transparent)
                    .clickable { onChange(i) }
                    .padding(vertical = 7.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    t,
                    color = if (selected) Color.White else colors.dim,
                    fontSize = 13.sp,
                    fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal
                )
            }
        }
    }
}

/**
 * 底部悬浮毛玻璃导航栏（对齐小米系统 / 应用商店规范）：
 * - 通过 navigationBarsPadding() 主动避让系统手势小白条，绝不重叠；
 * - 视觉高度 64dp、全圆角 32dp、左右 18dp、距小白条 10dp；
 * - 半透明竖向渐变 + 顶部 1dp 高光描边 + 柔和投影，营造磨砂玻璃质感（非纯白实心底）；
 * - 内部上下内边距收紧、文字单行不换行，确保「图标 + 文字」完整不裁切。
 */
@Composable
fun FloatingBottomBar(
    current: Tab,
    hazeState: HazeState,
    modifier: Modifier = Modifier,
    onChange: (Tab) -> Unit
) {
    val dark = isSystemInDarkTheme()
    val shape = RoundedCornerShape(25.dp)
    val inactive = if (dark) Color(0xFF8E8E93) else Color(0xFF9AA0AC)
    val coffeeAccent = pageColors(Tab.COFFEE).accent
    val gymAccent = pageColors(Tab.GYM).accent

    // 柔光玻璃配色（HyperOS 4 风格）：低透明度多层渐变，模拟玻璃透光
    // 深色模式：进一步降低不透明度（更透），并减淡高光描边
    val glassTop = if (dark) Color(0xB32C2C2E) else Color(0xCCFFFFFF)
    val glassMid = if (dark) Color(0x99252426) else Color(0xB3FCF7F0)
    val glassBottom = if (dark) Color(0x80201E1F) else Color(0x99F7F1E8)
    val sheen = if (dark) Color(0x2EFFFFFF) else Color(0xE6FFFFFF)
    val hairline = if (dark) Color(0x33FFFFFF) else Color(0x8CFFFFFF)
    val hairWidth = if (dark) 0.5.dp else 1.dp

    Box(
        modifier
            .fillMaxWidth()
            .navigationBarsPadding()
            .padding(bottom = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Box(
            Modifier
                .fillMaxWidth(0.66f)
                .height(50.dp)
                .shadow(
                    elevation = 12.dp,
                    shape = shape,
                    clip = false,
                    ambientColor = Color(0x1F000000),
                    spotColor = Color(0x14000000)
                )
                .clip(shape)
                .hazeChild(hazeState) {
                    blurRadius = 26.dp
                    backgroundColor = Color.Transparent
                    tints = listOf(HazeTint(Color.White.copy(alpha = 0.16f)))
                }
                .background(Brush.verticalGradient(listOf(glassTop, glassMid, glassBottom)))
        ) {
            // 柔光：顶部天光反射
            Box(
                Modifier
                    .matchParentSize()
                    .background(
                        Brush.verticalGradient(0f to sheen, 0.62f to Color.Transparent)
                    )
            )
            // 边缘高光描边（模拟玻璃反光）
            Box(
                Modifier
                    .matchParentSize()
                    .border(hairWidth, hairline, shape)
            )
            Row(
                Modifier.fillMaxWidth().fillMaxHeight(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                BarItem(
                    Tab.COFFEE, "咖啡", current, coffeeAccent, inactive,
                    Modifier.weight(1f)
                ) { onChange(Tab.COFFEE) }
                BarItem(
                    Tab.GYM, "健身", current, gymAccent, inactive,
                    Modifier.weight(1f)
                ) { onChange(Tab.GYM) }
            }
        }
    }
}

@Composable
private fun BarItem(
    tab: Tab,
    label: String,
    current: Tab,
    accent: Color,
    inactive: Color,
    modifier: Modifier,
    onClick: () -> Unit
) {
    val active = current == tab
    val c = if (active) accent else inactive
    Column(
        modifier
            .fillMaxHeight()
            .clip(RoundedCornerShape(25.dp))
            .clickable(onClick = onClick)
            .padding(vertical = 5.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(1.dp, Alignment.CenterVertically)
    ) {
        if (tab == Tab.COFFEE) CoffeeIcon(c, 20.dp) else GymIcon(c, 20.dp)
        Text(
            label,
            color = c,
            fontSize = 11.sp,
            lineHeight = 13.sp,
            fontWeight = if (active) FontWeight.SemiBold else FontWeight.Medium,
            maxLines = 1,
            softWrap = false
        )
    }
}
