package com.daily.checkin.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** 分段控件（周视图 / 月视图） */
@Composable
fun Segmented(
    items: List<String>,
    index: Int,
    onChange: (Int) -> Unit,
    colors: PageColors,
    accent: Color
) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(colors.seg)
            .padding(3.dp)
    ) {
        items.forEachIndexed { i, t ->
            val selected = i == index
            Box(
                Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(8.dp))
                    .background(if (selected) accent else Color.Transparent)
                    .clickable { onChange(i) }
                    .padding(vertical = 7.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    t,
                    color = if (selected) Color.White else colors.dim,
                    fontSize = 13.sp,
                    fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal
                )
            }
        }
    }
}

/**
 * 悬浮底栏（对齐小米系统应用规范：
 * 高度 60dp、圆角 30dp 全圆、左右 16dp、上下 10dp、悬浮投影 10dp）
 */
@Composable
fun FloatingBottomBar(current: Tab, onChange: (Tab) -> Unit) {
    val dark = isSystemInDarkTheme()
    val barBg = if (dark) Color(0xF21C1C1E) else Color(0xF5FFFFFF)
    val inactive = if (dark) Color(0xFF8E8E93) else Color(0xFF9AA0AC)
    val coffeeColors = pageColors(Tab.COFFEE)
    val gymColors = pageColors(Tab.GYM)

    Row(
        Modifier
            .padding(horizontal = 16.dp, vertical = 10.dp)
            .fillMaxWidth()
            .height(60.dp)
            .shadow(10.dp, RoundedCornerShape(30.dp))
            .clip(RoundedCornerShape(30.dp))
            .background(barBg),
        verticalAlignment = Alignment.CenterVertically
    ) {
        BarItem(
            Tab.COFFEE, "咖啡", current, coffeeColors.accent, inactive,
            Modifier.weight(1f)
        ) { onChange(Tab.COFFEE) }
        BarItem(
            Tab.GYM, "健身", current, gymColors.accent, inactive,
            Modifier.weight(1f)
        ) { onChange(Tab.GYM) }
    }
}

@Composable
private fun BarItem(
    tab: Tab,
    label: String,
    current: Tab,
    accent: Color,
    inactive: Color,
    modifier: Modifier,
    onClick: () -> Unit
) {
    val active = current == tab
    val c = if (active) accent else inactive
    Column(
        modifier
            .fillMaxHeight()
            .clip(RoundedCornerShape(30.dp))
            .clickable(onClick = onClick)
            .padding(vertical = 9.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(3.dp, Alignment.CenterVertically)
    ) {
        if (tab == Tab.COFFEE) CoffeeIcon(c, 24.dp) else GymIcon(c, 24.dp)
        Text(
            label,
            color = c,
            fontSize = 12.sp,
            fontWeight = if (active) FontWeight.SemiBold else FontWeight.Medium
        )
    }
}
