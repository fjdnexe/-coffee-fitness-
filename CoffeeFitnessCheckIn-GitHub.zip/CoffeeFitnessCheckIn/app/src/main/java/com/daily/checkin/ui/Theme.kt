package com.daily.checkin.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

/** 底部导航两个页签 */
enum class Tab { COFFEE, GYM }

/** 每个页签、每种模式下的完整配色 */
data class PageColors(
    val bg: Color,          // 页面背景
    val card: Color,        // 卡片
    val text: Color,        // 主文字
    val dim: Color,         // 次文字
    val accent: Color,      // 主题色（按钮/柱子/高亮）
    val accent2: Color,     // 主题浅色（渐变端）
    val heroA: Color,       // 打卡圆渐变亮
    val heroB: Color,       // 打卡圆渐变暗
    val track: Color,       // 底环/空柱
    val seg: Color,         // 分段控件轨道
    val chip: Color,        // 小图标底色
    val divider: Color      // 分隔线
)

@Composable
fun pageColors(tab: Tab): PageColors {
    val dark = isSystemInDarkTheme()
    return when (tab) {
        Tab.COFFEE -> if (!dark) PageColors(
            bg = Color(0xFFF6EFE5), card = Color.White, text = Color(0xFF2E231A),
            dim = Color(0xFF9C8B7B), accent = Color(0xFF9A7355), accent2 = Color(0xFFC4A187),
            heroA = Color(0xFFC9A98B), heroB = Color(0xFF8E6748), track = Color(0xFFEDE3D6),
            seg = Color(0xFFF0E7DC), chip = Color(0xFFEFE3D5), divider = Color(0xFFEFE7DD)
        ) else PageColors(
            bg = Color(0xFF14100D), card = Color(0xFF1F1A16), text = Color(0xFFF4EDE6),
            dim = Color(0xFF9B8E82), accent = Color(0xFFC9A183), accent2 = Color(0xFFA87C5B),
            heroA = Color(0xFF9A7355), heroB = Color(0xFF6E4E36), track = Color(0xFF2C2621),
            seg = Color(0xFF27211C), chip = Color(0xFF2C241C), divider = Color(0xFF2A241F)
        )

        Tab.GYM -> if (!dark) PageColors(
            bg = Color(0xFFECF0FB), card = Color.White, text = Color(0xFF1E2330),
            dim = Color(0xFF8B93A6), accent = Color(0xFF5E76E8), accent2 = Color(0xFF8FA3F5),
            heroA = Color(0xFF93A2F6), heroB = Color(0xFF5566DE), track = Color(0xFFE3E8F7),
            seg = Color(0xFFE6EAF8), chip = Color(0xFFE5EAFA), divider = Color(0xFFE6EAF6)
        ) else PageColors(
            bg = Color(0xFF0D1017), card = Color(0xFF181C25), text = Color(0xFFF0F2F8),
            dim = Color(0xFF8D94A6), accent = Color(0xFF8FA3F5), accent2 = Color(0xFF6C82EC),
            heroA = Color(0xFF6C82EC), heroB = Color(0xFF4657C6), track = Color(0xFF252A38),
            seg = Color(0xFF222734), chip = Color(0xFF232838), divider = Color(0xFF232837)
        )
    }
}

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    val dark = isSystemInDarkTheme()
    MaterialTheme(
        colorScheme = if (dark) darkColorScheme() else lightColorScheme(),
        content = content
    )
}

/**
 * 毛玻璃卡片的填充色。
 * 用半透明代替实底，让卡片背后那张「本来就柔焦」的背景照片透上来——
 * 视觉上就是系统级毛玻璃（透出虚化背景 + 边缘高光），
 * 而不需要为每张卡片单独跑一次离屏模糊，功耗几乎为零。
 */
@Composable
fun glassFill(colors: PageColors): Color {
    val dark = isSystemInDarkTheme()
    return colors.card.copy(alpha = if (dark) 0.70f else 0.62f)
}

/** 毛玻璃卡片的边缘高光（浅色为亮白描边，深色为极淡的白色细边） */
@Composable
fun glassRim(colors: PageColors): Color {
    val dark = isSystemInDarkTheme()
    return Color.White.copy(alpha = if (dark) 0.10f else 0.55f)
}
