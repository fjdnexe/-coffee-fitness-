package com.daily.checkin.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

/** 咖啡渐变（橙 → 玫红） */
val CoffeeA = Color(0xFFFF9F0A)
val CoffeeB = Color(0xFFFF375F)

/** 健身渐变（绿 → 天蓝，参考苹果运动圆环） */
val GymA = Color(0xFF30D158)
val GymB = Color(0xFF64D2FF)

/** 配色：跟随系统深色模式 */
data class Palette(
    val bg: Color,
    val card: Color,
    val text: Color,
    val dim: Color,
    val track: Color,
    val seg: Color
)

@Composable
fun palette(): Palette = if (isSystemInDarkTheme()) {
    Palette(
        bg = Color.Black,
        card = Color(0xFF1C1C1E),
        text = Color.White,
        dim = Color(0xFF8E8E93),
        track = Color(0xFF2C2C2E),
        seg = Color(0xFF1C1C1E)
    )
} else {
    Palette(
        bg = Color(0xFFF2F2F7),
        card = Color.White,
        text = Color(0xFF111111),
        dim = Color(0xFF6D6D72),
        track = Color(0xFFE5E5EA),
        seg = Color(0xFFE5E5EA)
    )
}

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    val dark = isSystemInDarkTheme()
    val scheme = if (dark) {
        darkColorScheme(background = Color.Black, surface = Color(0xFF1C1C1E), primary = CoffeeA)
    } else {
        lightColorScheme(background = Color(0xFFF2F2F7), surface = Color.White, primary = CoffeeA)
    }
    MaterialTheme(
        colorScheme = scheme,
        typography = Typography(
            displayLarge = TextStyle(
                fontWeight = FontWeight.Black,
                fontSize = 56.sp,
                letterSpacing = (-1.5).sp
            )
        ),
        content = content
    )
}
