package com.daily.checkin.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/**
 * 苹果运动风格圆环：
 * progress 0f..1f，超出 1 按 1 显示（达成后圆环闭合）
 */
@Composable
fun Ring(
    progress: Float,
    brush: Brush,
    track: Color,
    diameter: Dp = 150.dp,
    stroke: Dp = 16.dp
) {
    Canvas(Modifier.size(diameter)) {
        val w = stroke.toPx()
        val style = Stroke(w, cap = StrokeCap.Round)
        val inset = w / 2f
        val arcSize = Size(size.width - w, size.height - w)
        // 底环
        drawArc(track, 0f, 360f, false, Offset(inset, inset), arcSize, style = style)
        // 进度环
        if (progress > 0.001f) {
            drawArc(
                brush,
                -90f,
                360f * progress.coerceAtMost(1f),
                false,
                Offset(inset, inset),
                arcSize,
                style = style
            )
        }
    }
}
