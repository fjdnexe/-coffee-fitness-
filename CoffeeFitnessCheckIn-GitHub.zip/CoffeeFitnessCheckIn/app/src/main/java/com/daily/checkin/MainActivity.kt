package com.daily.checkin

import android.app.Dialog
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.Gravity
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.CompositionContext
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.rememberCompositionContext
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.platform.ViewCompositionStrategy
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.daily.checkin.ui.AppTheme
import com.daily.checkin.ui.FloatingBottomBar
import com.daily.checkin.ui.Root
import com.daily.checkin.ui.Tab

class MainActivity : ComponentActivity() {

    private val navTab = mutableStateOf(Tab.COFFEE)
    private var navDialog: Dialog? = null

    /** 顶层 Composition，供悬浮底栏的 ComposeView 复用（避免依赖 ViewTree 的 Owner 链） */
    private var parentComposition: CompositionContext? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // 显式指定状态栏/导航栏图标明暗，修复浅色模式下图标反色看不清的问题
        val dark = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
            Configuration.UI_MODE_NIGHT_YES
        val transparent = Color.TRANSPARENT
        enableEdgeToEdge(
            statusBarStyle = if (dark) {
                SystemBarStyle.dark(transparent)
            } else {
                SystemBarStyle.light(transparent, transparent)
            },
            navigationBarStyle = if (dark) {
                SystemBarStyle.dark(transparent)
            } else {
                SystemBarStyle.light(transparent, transparent)
            }
        )

        val store = Store(applicationContext)
        setContent {
            AppTheme {
                // 抓住顶层 Recomposer，挂到悬浮窗口里的 ComposeView 上
                parentComposition = rememberCompositionContext()
                Root(store, navTab)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        // 只在 Activity 处于前台时挂悬浮窗，避免后台 show 触发 BadTokenException
        window.decorView.post { showGlassNav(0) }
    }

    override fun onPause() {
        navDialog?.dismiss()
        navDialog = null
        super.onPause()
    }

    /**
     * 把底部导航放进一个独立的透明 [Dialog] 窗口。
     *
     * 这样它成为一个真正的窗口，可以用 Android 官方的**跨窗口模糊**
     * （[android.view.Window.setBackgroundBlurRadius]）模糊它背后的 Activity 内容。
     * 模糊由系统合成器（SurfaceFlinger）完成，App 端不跑 RenderEffect。
     */
    private fun showGlassNav(attempt: Int) {
        if (isFinishing || isDestroyed) return
        val composition = parentComposition
        if (composition == null) {
            // 首帧还没组合完，稍后重试（最多约 500ms）
            if (attempt < 10) {
                window.decorView.postDelayed({ showGlassNav(attempt + 1) }, 50)
            }
            return
        }
        navDialog?.dismiss()

        val dm = resources.displayMetrics
        val density = dm.density
        val widthPx = (dm.widthPixels * 0.66f).toInt()
        val heightPx = (51f * density).toInt()
        val radiusPx = 25.5f * density

        val dialog = Dialog(this, R.style.GlassNavDialog)

        val content = ComposeView(this).apply {
            // 关键：Dialog 的视图树里没有 ViewTreeLifecycleOwner，
            // 默认策略 DisposeOnViewTreeLifecycleDestroyed 会因为找不到 owner 直接崩。
            setViewCompositionStrategy(ViewCompositionStrategy.DisposeOnDetachedFromWindow)
            setParentCompositionContext(composition)
            setContent {
                AppTheme {
                    FloatingBottomBar(
                        current = navTab.value,
                        onChange = { navTab.value = it }
                    )
                }
            }
        }
        dialog.setContentView(content)

        // 透明圆角背景：不可见，仅用于告诉系统「模糊区域的形状是圆角胶囊」
        val bg = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = radiusPx
            setColor(Color.TRANSPARENT)
        }

        dialog.window?.let { w ->
            w.setBackgroundDrawable(bg)
            w.addFlags(
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
            )
            w.setLayout(widthPx, heightPx)
            w.setGravity(Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
            val lp = w.attributes
            lp.width = widthPx
            lp.height = heightPx
            lp.dimAmount = 0f
            // 让胶囊底边距离屏幕底 = 手势条高度 + 4dp（窗口向上偏移）
            lp.y = -(navigationBarHeight() + (4f * density).toInt())
            w.attributes = lp
        }

        try {
            dialog.show()
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                // 80px 左右是官方推荐的「磨砂玻璃」强度；超过 150 会明显掉帧
                dialog.window?.setBackgroundBlurRadius((80f * density).toInt())
            }
            navDialog = dialog
        } catch (e: Throwable) {
            // 悬浮窗失效时宁可没有底栏，也不能让整个 App 挂掉
            Log.w("GlassNav", "failed to show glass nav", e)
            runCatching { dialog.dismiss() }
            navDialog = null
        }
    }

    private fun navigationBarHeight(): Int {
        val insets = ViewCompat.getRootWindowInsets(window.decorView)
        return insets?.getInsets(WindowInsetsCompat.Type.navigationBars())?.bottom ?: 0
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        window.decorView.post { showGlassNav(0) }
    }

    override fun onDestroy() {
        navDialog?.dismiss()
        navDialog = null
        super.onDestroy()
    }
}
