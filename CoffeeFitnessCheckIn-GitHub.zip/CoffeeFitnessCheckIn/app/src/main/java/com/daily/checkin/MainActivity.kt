package com.daily.checkin

import android.content.res.Configuration
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.widget.PopupWindow
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.platform.ComposeView
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.ViewTreeLifecycleOwner
import androidx.lifecycle.ViewTreeViewModelStoreOwner
import androidx.savedstate.ViewTreeSavedStateRegistryOwner
import com.daily.checkin.ui.AppTheme
import com.daily.checkin.ui.FloatingBottomBar
import com.daily.checkin.ui.Root
import com.daily.checkin.ui.Tab

class MainActivity : ComponentActivity() {

    private val navTab = mutableStateOf(Tab.COFFEE)
    private var navPopup: PopupWindow? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // 显式指定状态栏/导航栏图标明暗，修复浅色模式下图标反色看不清的问题
        val dark = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
            Configuration.UI_MODE_NIGHT_YES
        val transparent = Color.TRANSPARENT
        enableEdgeToEdge(
            statusBarStyle = if (dark) {
                SystemBarStyle.dark(transparent)
            } else {
                SystemBarStyle.light(transparent, transparent)
            },
            navigationBarStyle = if (dark) {
                SystemBarStyle.dark(transparent)
            } else {
                SystemBarStyle.light(transparent, transparent)
            }
        )

        val store = Store(applicationContext)
        setContent {
            AppTheme {
                Root(store, navTab)
            }
        }

        // 等首帧布局完成后再挂载悬浮底栏，才能拿到正确的窗口尺寸与 insets
        window.decorView.post { showGlassNav() }
    }

    /**
     * 把底部导航放进一个独立的 [PopupWindow]。
     *
     * 这样它就是一个真正的「窗口」，可以用 Android 官方的**跨窗口模糊**
     * （[android.view.Window.setBackgroundBlurRadius]）去模糊它背后的 Activity 内容。
     * 该模糊由系统合成器（SurfaceFlinger）完成，App 端不跑 RenderEffect，
     * 既得到接近系统级的真毛玻璃，又把实时模糊的 GPU 开销彻底移走。
     */
    private fun showGlassNav() {
        if (isFinishing || isDestroyed) return
        navPopup?.dismiss()

        val dm = resources.displayMetrics
        val density = dm.density
        val widthPx = (dm.widthPixels * 0.66f).toInt()
        val heightPx = (51f * density).toInt()
        val radiusPx = 25.5f * density

        val content = ComposeView(this).apply {
            // PopupWindow 里的 ComposeView 不在 Activity 的 View 树内，需要手动补齐这三个 Owner
            ViewTreeLifecycleOwner.set(this, this@MainActivity)
            ViewTreeViewModelStoreOwner.set(this, this@MainActivity)
            ViewTreeSavedStateRegistryOwner.set(this, this@MainActivity)
            setContent {
                AppTheme {
                    FloatingBottomBar(
                        current = navTab.value,
                        onChange = { navTab.value = it }
                    )
                }
            }
        }

        // 透明圆角背景：它不作为可见底，只用来告诉系统「模糊区域是一个圆角胶囊」
        val bg = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = radiusPx
            setColor(Color.TRANSPARENT)
        }

        val popup = PopupWindow(content, widthPx, heightPx, false).apply {
            isOutsideTouchable = false
            isFocusable = false
            setBackgroundDrawable(bg)
        }

        val navBarBottom = navigationBarHeight()
        val offset = navBarBottom + (4f * density).toInt()
        popup.showAtLocation(
            window.decorView,
            Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL,
            0,
            -offset
        )

        // 系统级跨窗口模糊（Android 12+；本项目 minSdk 35，无需版本判断）
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            // 80px 左右是官方推荐的「磨砂玻璃」强度，超过 150 会明显掉帧
            popup.getWindow()?.setBackgroundBlurRadius((80f * density).toInt())
        }

        navPopup = popup
    }

    private fun navigationBarHeight(): Int {
        val insets = ViewCompat.getRootWindowInsets(window.decorView)
        return insets?.getInsets(WindowInsetsCompat.Type.navigationBars())?.bottom ?: 0
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        // 旋屏/尺寸变化时弹窗宽度不会自动跟随，重建一次
        window.decorView.post { showGlassNav() }
    }

    override fun onDestroy() {
        navPopup?.dismiss()
        navPopup = null
        super.onDestroy()
    }
}
