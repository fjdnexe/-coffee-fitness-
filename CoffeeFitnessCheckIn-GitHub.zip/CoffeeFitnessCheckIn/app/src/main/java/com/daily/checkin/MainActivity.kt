package com.daily.checkin

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.daily.checkin.ui.AppTheme
import com.daily.checkin.ui.Root

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // 沉浸式：内容延伸到状态栏与手势条下方，由界面自己处理内边距
        enableEdgeToEdge()
        val store = Store(applicationContext)
        setContent {
            AppTheme {
                Root(store)
            }
        }
    }
}
