package com.daily.checkin

import android.content.Context
import org.json.JSONObject
import java.time.DayOfWeek
import java.time.LocalDate

/**
 * 本地打卡数据（SharedPreferences + JSON），结构：
 * {"coffee":{"2026-10-17":2},"gym":{"2026-10-17":1}}
 */
class Store(context: Context) {
    private val prefs = context.getSharedPreferences("checkin", Context.MODE_PRIVATE)

    private fun load(): JSONObject = JSONObject(prefs.getString("data", "{}") ?: "{}")

    private fun save(o: JSONObject) {
        prefs.edit().putString("data", o.toString()).apply()
    }

    private fun record(type: String): Map<LocalDate, Int> {
        val obj = load().optJSONObject(type) ?: return emptyMap()
        val out = mutableMapOf<LocalDate, Int>()
        for (k in obj.keys()) out[LocalDate.parse(k)] = obj.optInt(k, 0)
        return out
    }

    /** 某天的次数 */
    fun count(type: String, date: LocalDate): Int = record(type)[date] ?: 0

    /** 增减次数，最低为 0 */
    fun add(type: String, date: LocalDate, delta: Int) {
        val root = load()
        val obj = root.optJSONObject(type) ?: JSONObject()
        val key = date.toString()
        val v = (obj.optInt(key, 0) + delta).coerceAtLeast(0)
        if (v == 0) obj.remove(key) else obj.put(key, v)
        root.put(type, obj)
        save(root)
    }

    /** 按给定日期序列输出每日次数 */
    fun series(type: String, dates: List<LocalDate>): List<Pair<LocalDate, Int>> {
        val m = record(type)
        return dates.map { it to (m[it] ?: 0) }
    }
}

/** 本周日期（周一 → 周日） */
fun weekDates(): List<LocalDate> {
    val start = LocalDate.now().with(DayOfWeek.MONDAY)
    return (0L..6L).map { start.plusDays(it) }
}

/** 本月日期（1 号 → 月末） */
fun monthDates(): List<LocalDate> {
    val today = LocalDate.now()
    val start = today.withDayOfMonth(1)
    return (0 until today.lengthOfMonth()).map { start.plusDays(it.toLong()) }
}
