package com.daily.checkin.ui

import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.daily.checkin.Store
import com.daily.checkin.monthDates
import com.daily.checkin.weekDates
import java.time.LocalDate

/** 根：底部两页签切换 + 数据版本号驱动全屏实时刷新 */
@Composable
fun Root(store: Store) {
    var tab by remember { mutableStateOf(Tab.COFFEE) }
    var version by remember { mutableIntStateOf(0) }

    val bg by animateColorAsState(
        targetValue = pageColors(tab).bg,
        animationSpec = tween(400),
        label = "bg"
    )

    Scaffold(
        containerColor = bg,
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        bottomBar = { FloatingBottomBar(tab) { tab = it } }
    ) { padding ->
        Box(Modifier.fillMaxSize().padding(padding)) {
            Crossfade(
                targetState = tab,
                animationSpec = tween(320),
                label = "tab"
            ) { t ->
                Page(store, t, version, onCheckIn = { type ->
                    store.add(type, LocalDate.now(), 1)
                    version++
                })
            }
        }
    }
}

/** 单页内容：标题 → 大圆 → 统计 → 记录 → 连续成就 */
@Composable
private fun Page(
    store: Store,
    tab: Tab,
    version: Int,
    onCheckIn: (String) -> Unit
) {
    val colors = pageColors(tab)
    val isCoffee = tab == Tab.COFFEE
    val type = if (isCoffee) "coffee" else "gym"
    val title = if (isCoffee) "咖啡打卡" else "健身打卡"
    val subtitle = if (isCoffee) "一杯好咖啡，唤醒更好的自己" else "每一次坚持，都是更强的自己"

    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp)
    ) {
        Spacer(Modifier.height(18.dp))
        Text(title, color = colors.text, fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(4.dp))
        Text(subtitle, color = colors.dim, fontSize = 13.sp)
        Spacer(Modifier.height(6.dp))

        Hero(store, type, colors, version) { onCheckIn(type) }
        StatsCard(store, type, colors, version)
        Spacer(Modifier.height(16.dp))
        RecordsCard(store, type, colors, version)
        Spacer(Modifier.height(16.dp))
        StreakCard(store, type, colors, version)
        Spacer(Modifier.height(28.dp))
    }
}

/** 打卡记录卡：标题 + 周/月分段 + 图表 */
@Composable
private fun RecordsCard(store: Store, type: String, colors: PageColors, version: Int) {
    var mode by rememberSaveable { mutableStateOf(0) }
    val dates = if (mode == 0) weekDates() else monthDates()
    val data = remember(version, mode, type) { store.series(type, dates) }

    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(24.dp))
            .background(colors.card)
            .padding(18.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                "打卡记录",
                color = colors.text,
                fontSize = 16.sp,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(Modifier.weight(1f))
            Box(Modifier.width(168.dp)) {
                Segmented(
                    listOf("周视图", "月视图"),
                    mode,
                    { mode = it },
                    colors,
                    colors.accent
                )
            }
        }
        Spacer(Modifier.height(16.dp))
        Chart(data, dates, colors.accent2, colors.accent, colors)
    }
}
