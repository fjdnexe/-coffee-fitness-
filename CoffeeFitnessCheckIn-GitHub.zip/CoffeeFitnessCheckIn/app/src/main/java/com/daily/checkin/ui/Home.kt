package com.daily.checkin.ui

import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.daily.checkin.R
import com.daily.checkin.Store
import com.daily.checkin.monthDates
import com.daily.checkin.weekDates
import dev.chrisbanes.haze.HazeState
import dev.chrisbanes.haze.HazeTint
import dev.chrisbanes.haze.haze
import dev.chrisbanes.haze.hazeChild
import java.time.LocalDate

/**
 * 根：底部两页签切换 + 数据版本号驱动全屏实时刷新。
 *
 * 采用「全屏背景 Box + 内容层 + 顶部状态栏过渡遮罩 + 底部悬浮毛玻璃导航」的分层结构，
 * 取代原先的 Scaffold 直切布局：背景可无缝延伸进状态栏、顶部无硬切割，
 * 底部导航通过系统导航栏 insets 主动避让手势小白条。
 */
@Composable
fun Root(store: Store) {
    var tab by remember { mutableStateOf(Tab.COFFEE) }
    var version by remember { mutableIntStateOf(0) }

    val colors = pageColors(tab)
    val bg by animateColorAsState(
        targetValue = colors.bg,
        animationSpec = tween(400),
        label = "bg"
    )

    val dark = isSystemInDarkTheme()
    val statusTop = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
    val navBottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
    // 滚动内容底部预留空间，让最后一项能滚到胶囊上方；胶囊本身真悬浮在内容之上
    val contentBottomInset = navBottom + 56.dp + 24.dp
    // 顶部微亮暖色，柔化照片与状态栏衔接
    val topGlow = lerp(bg, Color.White, if (dark) 0.06f else 0.32f)
    // 背景模糊：内容层作为 haze 源，胶囊与状态栏作为 hazeChild 消费
    val hazeState = remember { HazeState() }

    Box(Modifier.fillMaxSize()) {
        // ① Haze 源层：背景色 + 顶部照片 + 可滚动内容（内容可穿到胶囊/状态栏下方）
        Box(Modifier.fillMaxSize().haze(hazeState)) {
            Box(Modifier.fillMaxSize().background(bg))

            // 顶部背景照片（随页签切换），底部渐隐融入页面底色
            Box(Modifier.fillMaxWidth().fillMaxHeight(0.60f)) {
                Image(
                    painter = painterResource(
                        if (tab == Tab.COFFEE) R.drawable.bg_coffee else R.drawable.bg_gym
                    ),
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
                Box(
                    Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                0f to bg.copy(alpha = 0.10f),
                                0.50f to bg.copy(alpha = 0.42f),
                                0.80f to bg.copy(alpha = 0.88f),
                                1f to bg
                            )
                        )
                )
                Box(
                    Modifier
                        .fillMaxWidth()
                        .fillMaxHeight(0.30f)
                        .background(
                            Brush.verticalGradient(
                                listOf(topGlow.copy(alpha = 0.55f), Color.Transparent)
                            )
                        )
                )
            }

            // 内容层：不做底部让位，真正滚到胶囊下方
            Crossfade(
                targetState = tab,
                animationSpec = tween(320),
                label = "tab"
            ) { t ->
                Page(
                    store = store,
                    tab = t,
                    version = version,
                    bottomInset = contentBottomInset,
                    onCheckIn = { type ->
                        store.add(type, LocalDate.now(), 1)
                        version++
                    }
                )
            }
        }

        // ② 顶部状态栏：渐变模糊遮罩（上强下弱），替代生硬纯色分割线
        Box(
            Modifier
                .align(Alignment.TopCenter)
                .fillMaxWidth()
                .height(statusTop + 18.dp)
                .hazeChild(hazeState) {
                    blurRadius = 20.dp
                    backgroundColor = Color.Transparent
                    tints = listOf(HazeTint(bg.copy(alpha = 0.18f)))
                    mask = Brush.verticalGradient(listOf(Color.Black, Color.Transparent))
                }
        )

        // ③ 底部真悬浮柔光玻璃胶囊（内容从其下方穿过并被实时模糊）
        FloatingBottomBar(
            current = tab,
            hazeState = hazeState,
            modifier = Modifier.align(Alignment.BottomCenter),
            onChange = { tab = it }
        )
    }
}

/** 单页内容：标题 → 大圆 → 统计 → 记录 → 连续成就 */
@Composable
private fun Page(
    store: Store,
    tab: Tab,
    version: Int,
    bottomInset: Dp,
    onCheckIn: (String) -> Unit
) {
    val colors = pageColors(tab)
    val isCoffee = tab == Tab.COFFEE
    val type = if (isCoffee) "coffee" else "gym"
    val title = if (isCoffee) "咖啡打卡" else "健身打卡"
    val subtitle = if (isCoffee) "一杯好咖啡，唤醒更好的自己" else "每一次坚持，都是更强的自己"

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .statusBarsPadding()
            .padding(horizontal = 20.dp)
    ) {
        // 加大顶部安全边距，避免标题贴住系统状态栏时间图标
        Spacer(Modifier.height(22.dp))
        Text(title, color = colors.text, fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(4.dp))
        Text(subtitle, color = colors.dim, fontSize = 13.sp)
        Spacer(Modifier.height(6.dp))

        Hero(store, type, colors, version) { onCheckIn(type) }
        StatsCard(store, type, colors, version)
        Spacer(Modifier.height(16.dp))
        RecordsCard(store, type, colors, version)
        Spacer(Modifier.height(16.dp))
        StreakCard(store, type, colors, version)
        Spacer(Modifier.height(bottomInset))
    }
}

/** 打卡记录卡：标题 + 周/月分段 + 图表 */
@Composable
private fun RecordsCard(store: Store, type: String, colors: PageColors, version: Int) {
    var mode by rememberSaveable { mutableStateOf(0) }
    val dates = if (mode == 0) weekDates() else monthDates()
    val data = remember(version, mode, type) { store.series(type, dates) }

    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(24.dp))
            .background(colors.card)
            .padding(18.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                "打卡记录",
                color = colors.text,
                fontSize = 16.sp,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(Modifier.weight(1f))
            Box(Modifier.width(168.dp)) {
                Segmented(
                    listOf("周视图", "月视图"),
                    mode,
                    { mode = it },
                    colors,
                    colors.accent
                )
            }
        }
        Spacer(Modifier.height(16.dp))
        Chart(data, dates, colors.accent2, colors.accent, colors)
    }
}
