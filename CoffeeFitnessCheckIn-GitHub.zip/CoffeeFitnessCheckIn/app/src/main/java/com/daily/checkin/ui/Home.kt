package com.daily.checkin.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.daily.checkin.Store
import java.time.LocalDate
import java.time.format.TextStyle
import java.util.Locale

/** 页面路由：首页 / 详情 */
@Composable
fun Root(store: Store) {
    var detail by remember { mutableStateOf<String?>(null) }
    val type = detail
    if (type == null) {
        Home(store, onOpen = { detail = it })
    } else {
        Detail(store, type, onBack = { detail = null })
    }
}

/** 首页：大标题 + 两张打卡卡片 */
@Composable
fun Home(store: Store, onOpen: (String) -> Unit) {
    val p = palette()
    val today = LocalDate.now()
    val week = today.dayOfWeek.getDisplayName(TextStyle.SHORT, Locale.CHINESE)
    Column(
        Modifier
            .fillMaxSize()
            .background(p.bg)
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(horizontal = 20.dp)
    ) {
        Spacer(Modifier.height(28.dp))
        Text("打卡", color = p.text, fontSize = 42.sp, fontWeight = FontWeight.Black)
        Spacer(Modifier.height(4.dp))
        Text(
            "${today.monthValue}月${today.dayOfMonth}日 星期$week",
            color = p.dim,
            fontSize = 15.sp
        )
        Spacer(Modifier.height(24.dp))
        MetricCard(store, "coffee", "咖啡", "杯", 3, CoffeeA, CoffeeB, onOpen)
        Spacer(Modifier.height(16.dp))
        MetricCard(store, "gym", "健身", "次", 1, GymA, GymB, onOpen)
    }
}

/** 单个指标卡片：圆环 + 今日计数 + 快捷打卡 */
@Composable
private fun MetricCard(
    store: Store,
    type: String,
    title: String,
    unit: String,
    goal: Int,
    cA: Color,
    cB: Color,
    onOpen: (String) -> Unit
) {
    val p = palette()
    val today = LocalDate.now()
    val cur = store.count(type, today)
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(28.dp))
            .background(p.card)
            .clickable { onOpen(type) }
            .padding(20.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(title, color = p.text, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.weight(1f))
            Text("查看详情 ›", color = p.dim, fontSize = 14.sp)
        }
        Spacer(Modifier.height(18.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(contentAlignment = Alignment.Center) {
                Ring(
                    progress = cur.toFloat() / goal,
                    brush = Brush.sweepGradient(listOf(cA, cB, cA)),
                    track = p.track,
                    diameter = 132.dp,
                    stroke = 14.dp
                )
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("$cur", color = p.text, fontSize = 40.sp, fontWeight = FontWeight.Black)
                    Text("/$goal $unit", color = p.dim, fontSize = 13.sp)
                }
            }
            Spacer(Modifier.weight(1f))
            Column(
                horizontalAlignment = Alignment.End,
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Btn("打卡 +1", Brush.horizontalGradient(listOf(cA, cB))) {
                    store.add(type, today, 1)
                }
                Btn("撤销 -1", Brush.horizontalGradient(listOf(p.track, p.track)), p.dim) {
                    store.add(type, today, -1)
                }
            }
        }
    }
}
