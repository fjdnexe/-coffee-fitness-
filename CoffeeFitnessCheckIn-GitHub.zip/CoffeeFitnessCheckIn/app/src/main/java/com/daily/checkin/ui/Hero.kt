package com.daily.checkin.ui

import android.os.VibrationEffect
import android.os.Vibrator
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateIntAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.daily.checkin.Store
import java.time.LocalDate

/**
 * 首屏打卡大圆：点击 → 实时震动 + 计数动画
 */
@Composable
fun Hero(
    store: Store,
    type: String,
    colors: PageColors,
    version: Int,
    onCheckIn: () -> Unit
) {
    val isCoffee = type == "coffee"
    val todayCount = remember(version) { store.count(type, LocalDate.now()) }
    val anim by animateIntAsState(
        targetValue = todayCount,
        animationSpec = tween(450, easing = FastOutSlowInEasing),
        label = "heroCount"
    )
    val context = LocalContext.current
    val vibrator = remember { context.getSystemService(Vibrator::class.java) }

    val hintA = if (isCoffee) "好心情" else "自律"
    val hintB = if (isCoffee) "从一杯咖啡开始" else "让生活更有力量"

    Box(
        Modifier
            .fillMaxWidth()
            .height(248.dp)
    ) {
        Box(
            Modifier.align(Alignment.Center),
            contentAlignment = Alignment.Center
        ) {
            // 外光晕（柔光扩散）
            Box(
                Modifier
                    .size(178.dp)
                    .clip(CircleShape)
                    .background(
                        Brush.radialGradient(
                            listOf(colors.heroA.copy(alpha = 0.30f), colors.heroA.copy(alpha = 0f))
                        )
                    )
            )
            // 玻璃外环（高光边）
            Box(
                Modifier
                    .size(160.dp)
                    .clip(CircleShape)
                    .background(
                        Brush.linearGradient(
                            listOf(
                                Color.White.copy(alpha = 0.75f),
                                colors.heroA.copy(alpha = 0.18f),
                                Color.White.copy(alpha = 0.30f)
                            )
                        )
                    )
            )
            // 主盘（玻璃硬币质感）
            Box(
                Modifier
                    .size(150.dp)
                    .shadow(
                        elevation = 14.dp,
                        shape = CircleShape,
                        clip = false,
                        ambientColor = colors.heroB.copy(alpha = 0.55f),
                        spotColor = colors.heroB.copy(alpha = 0.55f)
                    )
                    .clip(CircleShape)
                    .background(Brush.linearGradient(listOf(colors.heroA, colors.heroB)))
                    .border(1.5.dp, Color.White.copy(alpha = 0.55f), CircleShape)
                    .clickable {
                        // 实时震动反馈
                        if (vibrator?.hasVibrator() == true) {
                            vibrator.vibrate(VibrationEffect.createOneShot(35, 180))
                        }
                        onCheckIn()
                    },
                contentAlignment = Alignment.Center
            ) {
                // 顶部玻璃高光 + 底部内阴影
                Box(
                    Modifier
                        .matchParentSize()
                        .background(
                            Brush.verticalGradient(
                                0f to Color.White.copy(alpha = 0.42f),
                                0.42f to Color.White.copy(alpha = 0.02f),
                                1f to Color.Black.copy(alpha = 0.14f)
                            )
                        )
                )
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    if (isCoffee) CoffeeIcon(Color.White, 37.dp) else GymIcon(Color.White, 37.dp)
                    Spacer(Modifier.height(7.dp))
                    Text(
                        "今日打卡",
                        color = Color.White,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(Modifier.height(3.dp))
                    Text(
                        if (isCoffee) "已喝 $anim 杯" else "已完成 $anim 次",
                        color = Color.White.copy(alpha = 0.9f),
                        fontSize = 12.sp
                    )
                }
            }
        }
        // 提示文案：放在按钮右下方（按钮右侧留白区），既不压按钮，也不压下方统计卡片
        Column(
            Modifier
                .align(Alignment.BottomEnd)
                .padding(end = 2.dp, bottom = 6.dp),
            horizontalAlignment = Alignment.End
        ) {
            Text(hintA, color = colors.dim, fontSize = 12.sp, fontWeight = FontWeight.Medium)
            Spacer(Modifier.height(2.dp))
            Text(hintB, color = colors.dim, fontSize = 12.sp)
        }
    }
}
